//
//  ImageCache.swift
//  Gallax
//
//  Created by sruthi.e01 on 25/10/26.
//

import CryptoKit
import UIKit

/// Two-tier image cache: an `NSCache` in memory backed by JPEG files in
/// `Caches/`. Entries are keyed by the SHA256 of the cache key so the same
/// key always maps to the same file.
///
/// Explicitly `nonisolated` because the project defaults to main-actor
/// isolation, and cache I/O must not be forced onto the main thread.
nonisolated final class ImageCache: @unchecked Sendable {

    static let shared = ImageCache()

    private let memoryCache = NSCache<NSString, UIImage>()
    private let diskDirectory: URL
    private let fileManager = FileManager.default

    init(countLimit: Int = 150,
         memoryLimitBytes: Int = 40 * 1024 * 1024) {
        memoryCache.countLimit = countLimit
        memoryCache.totalCostLimit = memoryLimitBytes

        let caches = fileManager.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        diskDirectory = caches.appendingPathComponent("GallaxImageCache", isDirectory: true)
        try? fileManager.createDirectory(at: diskDirectory, withIntermediateDirectories: true)
    }

    // MARK: - Read

    func image(for key: String) -> UIImage? {
        if let cached = memoryCache.object(forKey: key as NSString) {
            return cached
        }
        let fileURL = diskURL(for: key)
        guard let data = try? Data(contentsOf: fileURL),
              let image = UIImage(data: data) else {
            return nil
        }
        storeInMemory(image, for: key)
        return image
    }

    // MARK: - Write

    func insert(_ image: UIImage, data: Data, for key: String) {
        storeInMemory(image, for: key)
        let fileURL = diskURL(for: key)
        guard !fileManager.fileExists(atPath: fileURL.path) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }

    func removeAll() {
        memoryCache.removeAllObjects()
        try? fileManager.removeItem(at: diskDirectory)
        try? fileManager.createDirectory(at: diskDirectory, withIntermediateDirectories: true)
    }

    // MARK: - Internals

    private func storeInMemory(_ image: UIImage, for key: String) {
        // Cost is the decoded byte footprint, which is what actually drives
        // memory pressure. `size` is in points, so scale has to be squared in
        // to get real pixels.
        let cost = Int(image.size.width * image.size.height * image.scale * image.scale * 4)
        memoryCache.setObject(image, forKey: key as NSString, cost: cost)
    }

    private func diskURL(for key: String) -> URL {
        let hashed = SHA256.hash(data: Data(key.utf8))
            .compactMap { String(format: "%02x", $0) }
            .joined()
        return diskDirectory.appendingPathComponent(hashed).appendingPathExtension("jpg")
    }
}
