//
//  ImageDownsampler.swift
//  Gallax
//
//  Created by sruthi.e01 on 25/10/26.
//

import ImageIO
import UIKit

/// Thumbnail generation via ImageIO.
///
/// `CGImageSourceCreateThumbnailAtIndex` decodes straight to the target size,
/// so a 4000px photo never has to exist in memory at full resolution. This is
/// what keeps the gallery list cheap when scrolling hundreds of rows.
nonisolated enum ImageDownsampler {

    /// Longest-edge size used for list row thumbnails.
    static let thumbnailMaxPixel: CGFloat = 300

    /// Longest-edge size used for the full-screen detail image.
    static let detailMaxPixel: CGFloat = 1200

    /// Scale applied to the requested point size. Fixed rather than read from
    /// `UIScreen.main`, which is deprecated and main-actor isolated and so
    /// cannot be touched from the background threads that perform decoding.
    /// 3 matches the densest current iPhone displays; oversampling slightly on
    /// a 2x device costs little and keeps thumbnails crisp everywhere.
    static let defaultScale: CGFloat = 3

    static func downsample(data: Data,
                           maxPixelSize: CGFloat,
                           scale: CGFloat = defaultScale) -> UIImage? {
        let sourceOptions = [kCGImageSourceShouldCache: false] as CFDictionary
        guard let source = CGImageSourceCreateWithData(data as CFData, sourceOptions) else {
            return nil
        }
        return downsample(source: source, maxPixelSize: maxPixelSize, scale: scale)
    }

    private static func downsample(source: CGImageSource,
                                   maxPixelSize: CGFloat,
                                   scale: CGFloat) -> UIImage? {
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixelSize * scale
        ]
        guard let cgImage = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else {
            return nil
        }
        return UIImage(cgImage: cgImage, scale: scale, orientation: .up)
    }

    /// Produces a compressed thumbnail suitable for persisting alongside the item.
    static func thumbnailData(from data: Data,
                              maxPixelSize: CGFloat = thumbnailMaxPixel,
                              compression: CGFloat = 0.7) -> Data? {
        downsample(data: data, maxPixelSize: maxPixelSize)?
            .jpegData(compressionQuality: compression)
    }
}
