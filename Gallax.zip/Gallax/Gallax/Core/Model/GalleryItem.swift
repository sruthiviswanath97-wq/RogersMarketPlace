//
//  GalleryItem.swift
//  Gallax
//
//  Created by sruthi.e01 on 25/10/26.
//

import Foundation
import SwiftData

@Model
final class GalleryItem {

    @Attribute(.unique) var localId: UUID

    /// Server-assigned identifier. `nil` until the create operation has synced.
    var remoteId: String?

    var title: String
    var itemDescription: String

    /// Full-resolution image chosen by the user. Stored externally to keep
    /// the SwiftData store light.
    @Attribute(.externalStorage) var imageData: Data?

    /// Downsampled copy used by list rows so we never decode full images in a list.
    @Attribute(.externalStorage) var thumbnailData: Data?

    /// Remote image URL for items that came from the server.
    var imageURL: String?

    var isFavorite: Bool

    /// Last local mutation. This is the client side of last-write-wins.
    var updatedAt: Date

    /// `meta.updatedAt` observed from the server. The remote side of last-write-wins.
    var remoteUpdatedAt: Date?

    var syncStatusRaw: String

    /// Soft-delete marker so a delete can survive offline until it is replayed.
    var isDeleted: Bool

    /// True for items the user created on this device. The mock backend
    /// acknowledges creates without persisting them, so these items own their
    /// own truth and must not be treated as sync failures when the server
    /// later reports that their id does not exist.
    var isLocallyCreated: Bool = false

    init(localId: UUID = UUID(),
         remoteId: String? = nil,
         title: String,
         itemDescription: String,
         imageData: Data? = nil,
         thumbnailData: Data? = nil,
         imageURL: String? = nil,
         isFavorite: Bool = false,
         updatedAt: Date = .now,
         remoteUpdatedAt: Date? = nil,
         syncStatus: SyncStatus = .pending,
         isDeleted: Bool = false,
         isLocallyCreated: Bool = false) {
        self.localId = localId
        self.remoteId = remoteId
        self.title = title
        self.itemDescription = itemDescription
        self.imageData = imageData
        self.thumbnailData = thumbnailData
        self.imageURL = imageURL
        self.isFavorite = isFavorite
        self.updatedAt = updatedAt
        self.remoteUpdatedAt = remoteUpdatedAt
        self.syncStatusRaw = syncStatus.rawValue
        self.isDeleted = isDeleted
        self.isLocallyCreated = isLocallyCreated
    }

    var syncStatus: SyncStatus {
        get { SyncStatus(rawValue: syncStatusRaw) ?? .pending }
        set { syncStatusRaw = newValue.rawValue }
    }
}
