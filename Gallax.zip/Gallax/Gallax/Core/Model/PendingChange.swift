//
//  PendingChange.swift
//  Gallax
//
//  Created by sruthi.e01 on 25/10/26.
//

import Foundation
import SwiftData

/// A durable, replayable record of one offline mutation.
///
/// This is the real offline queue: every create/update/delete is written here
/// inside the same save as the local model change, so a change can never be
/// lost by the app being backgrounded or killed before it reaches the server.
@Model
final class PendingChange {

    @Attribute(.unique) var id: UUID

    /// The `GalleryItem.localId` this change applies to.
    var itemLocalId: UUID

    var operationRaw: String

    /// Encoded `ChangePayload`, replayed verbatim when connectivity returns.
    var payloadData: Data?

    /// Client timestamp used for last-write-wins resolution.
    var clientUpdatedAt: Date

    var statusRaw: String
    var retryCount: Int
    var lastError: String?
    var createdAt: Date

    init(id: UUID = UUID(),
         itemLocalId: UUID,
         operation: SyncOperation,
         payload: ChangePayload? = nil,
         clientUpdatedAt: Date = .now,
         status: SyncStatus = .pending,
         retryCount: Int = 0,
         lastError: String? = nil,
         createdAt: Date = .now) {
        self.id = id
        self.itemLocalId = itemLocalId
        self.operationRaw = operation.rawValue
        self.payloadData = payload.flatMap { try? JSONEncoder().encode($0) }
        self.clientUpdatedAt = clientUpdatedAt
        self.statusRaw = status.rawValue
        self.retryCount = retryCount
        self.lastError = lastError
        self.createdAt = createdAt
    }

    var operation: SyncOperation {
        get { SyncOperation(rawValue: operationRaw) ?? .update }
        set { operationRaw = newValue.rawValue }
    }

    var status: SyncStatus {
        get { SyncStatus(rawValue: statusRaw) ?? .pending }
        set { statusRaw = newValue.rawValue }
    }

    var payload: ChangePayload? {
        guard let payloadData else { return nil }
        return try? JSONDecoder().decode(ChangePayload.self, from: payloadData)
    }
}

/// The mutable fields a queued change carries to the server.
///
/// `nonisolated` so its `Codable` conformance can be used from the background
/// contexts that encode and decode the queue.
nonisolated struct ChangePayload: Codable, Equatable {
    var title: String
    var description: String
    var isFavorite: Bool
}
